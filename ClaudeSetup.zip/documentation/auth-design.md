# Auth Design — Sprint 1 (Registration / Login / Logout)

Status: draft for review, nothing implemented yet. Matches the layering in `CLAUDE.md`
(Domain → Persistence → Application → Server) and the decision from the last session:
self-hosted JWT, not a third-party OAuth stand-in.

## 1. Scope for Sprint 1

- Register a new account, log in, log out.
- Hashed password storage + a basic username/password policy (course hard requirement
  if we build accounts at all — we already decided to).
- No refresh tokens, no server-side revocation list, no roles/permissions beyond
  "authenticated or not." If a later sprint needs session persistence across the
  game-save/replay feature, revisit then — don't build it now.

## 2. Who owns what

| Layer | New responsibility |
|---|---|
| Domain | `User` entity (already exists); username/password **policy** rules; `IUserRepository` contract |
| Persistence | `UserRepository` (EF implementation of `IUserRepository`) |
| Application | Ports (`IPasswordHasher`, `IJwtTokenService`) + their implementations; `JwtOptions`; `IAuthService`/`AuthService` use case; DI wiring extensions |
| Shared | Request/response DTOs (`RegisterRequestDto`, `LoginRequestDto`, `AuthResponseDto`) |
| Server | `AuthController`; JWT bearer middleware registration in `Program.cs`; config |

This keeps the existing convention: all composition/DI extension methods live in
`Application/Core/Extensions/IServiceCollectionExtension.cs` (that's already where
`AddCheckersDbContext` lives), and `Server/Program.cs` just calls them. Domain stays
free of any ASP.NET Core / JWT / hashing package references — it only has the policy
and the repository *interface*.

## 3. Concrete file list

```
Domain/
  Entities/User.cs                         (edit — see §4)
  Policies/UsernamePolicy.cs                (new)
  Policies/PasswordPolicy.cs                (new)
  Repositories/IUserRepository.cs           (new)

Persistence/
  Data/Repositories/UserRepository.cs       (new)

Application/
  Abstractions/IPasswordHasher.cs           (new)
  Abstractions/IJwtTokenService.cs          (new)
  Options/JwtOptions.cs                     (new)
  Security/PasswordHasher.cs                (new — wraps Identity's PasswordHasher<T>)
  Security/JwtTokenService.cs               (new)
  Auth/IAuthService.cs                      (new)
  Auth/AuthService.cs                       (new)
  Core/Extensions/IServiceCollectionExtension.cs   (edit — add AddCheckersRepositories, AddCheckersAuth)
  Core/Profiles/CheckerProfile.cs           (edit — map DTOs below if needed)

Shared/
  DTOs/RegisterRequestDto.cs                (new)
  DTOs/LoginRequestDto.cs                   (new)
  DTOs/AuthResponseDto.cs                   (new)

Server/
  Controllers/AuthController.cs             (new)
  Program.cs                                (edit — JWT bearer auth, call new extensions)
  appsettings.json / appsettings.Development.json   (edit — add "Jwt" section, see §7)
```

## 4. `User` entity

Recommend renaming `Password` → `PasswordHash` now that it's about to hold a real
hash, and updating `UserEntityConfiguration` to match (add `.HasColumnName("Password")`
there if you want to keep the existing DB column name and avoid a cosmetic migration
diff). Everything else about the entity can stay as-is for Sprint 1.

## 5. Policies (Domain) — the "custom password policy" requirement

Keep these as plain static validators, no external package, so they're trivially
unit-testable and have zero dependencies:

```csharp
// Domain/Policies/PasswordPolicy.cs
public static class PasswordPolicy
{
    public const int MinLength = 8;

    public static IReadOnlyList<string> Validate(string password)
    {
        var errors = new List<string>();
        if (string.IsNullOrWhiteSpace(password) || password.Length < MinLength)
            errors.Add($"Password must be at least {MinLength} characters.");
        if (!password.Any(char.IsDigit))
            errors.Add("Password must contain at least one digit.");
        if (!password.Any(char.IsLetter))
            errors.Add("Password must contain at least one letter.");
        return errors;
    }
}
```

Same shape for `UsernamePolicy` (e.g. 3–30 chars, letters/digits/underscore only).
`AuthService` calls both during registration and returns the errors as part of the
failed result — this is the artifact that satisfies the "custom username/password
policy" grading line, so keep it visible/named rather than inlining the checks.

## 6. Token strategy

- **Library:** `System.IdentityModel.Tokens.Jwt` (Application.csproj) for issuing,
  `Microsoft.AspNetCore.Authentication.JwtBearer` (Server.csproj) for validating.
- **Claims:** `NameIdentifier` = User.Id, `Name`/`unique_name` = Username. Keep it
  minimal; add more only when a later sprint needs them.
- **Expiry:** short-lived access token only (suggest 60–120 min) via `JwtOptions`.
  No refresh token for Sprint 1.
- **Signing:** symmetric key (`HMAC-SHA256`) is enough here — no need for
  asymmetric keys for a single self-hosted API.
- **Logout:** stateless. The server has no session to invalidate; `/api/auth/logout`
  can be a thin `[Authorize]` endpoint that does nothing but prove the token
  validated (useful smoke test), while the actual "log out" is the client dropping
  the token. If a grader/user story demands server-enforced logout, that needs a
  revocation table — explicitly deferred, not forgotten.

## 7. Config & secrets — please don't commit the signing key

Add a `Jwt` section to `appsettings.json` for the *non-secret* parts only
(`Issuer`, `Audience`, `AccessTokenExpirationMinutes`); put `SigningKey` into
`dotnet user-secrets` for local dev and an environment variable (`Jwt__SigningKey`)
for Staging/Prod, the same way the SQL Server password should eventually move out
of plain appsettings.

Flagging while I'm in here: `Server/appsettings.json` already has a real AutoMapper
license key and the DB password committed in plain text (confirmed in git history,
not gitignored). Not blocking for auth work, but since the repo needs to be public
per the course brief, worth moving those to user-secrets in the same pass rather
than adding a third plaintext secret next to them.

## 8. Prerequisites you'll hit

- DB-first: you'll need to create the `Users` table yourself (SSMS/T-SQL/whatever)
  matching `UserEntityConfiguration` — `Id` PK, `User`/`Password`/`Email`/
  `First_Name`/`Last_Name`/`Middle_Name`/`Nick_Name` columns (see §4 for the column
  name mapping). No migration will do this for you.
- `UnitTests.csproj` had no project references — now fixed: references `Domain`,
  `Shared`, `Application`, plus `Moq`. `AuthService` is `internal`, so
  `Application.csproj` also needed `InternalsVisibleTo` for `UnitTests`.

## 9. Endpoints

```
POST /api/auth/register   -> 201 + AuthResponseDto, or 400 + validation errors
POST /api/auth/login      -> 200 + AuthResponseDto, or 401
POST /api/auth/logout     -> [Authorize] 200 (stateless no-op, see §6)
```

## 10. Open decisions for you to confirm

1. Rename `Password` → `PasswordHash` now, or leave it and just start hashing into
   the existing field? (recommend renaming — see §4)
2. OK with stateless logout for Sprint 1 (§6), or do you want revocation now?
3. OK with `PasswordHasher<T>` from `Microsoft.Extensions.Identity.Core` rather than
   pulling in BCrypt.Net-Next or another third-party hasher? Either works; Identity's
   is already a Microsoft package and needs no new dependency decision recorded.

**Resolved 2026-10-14** — implemented per the recommendations above (1: renamed,
2: stateless, 3: `PasswordHasher<T>`). Two corrections to §2's layer table, both per
the user's own call rather than this doc's original plan:

- `IUserRepository` lives in `Persistence.Data.IRepositories`, but `UserRepository`
  **implements it from the Application layer** (`Application.Core.Repositories`),
  injecting `CheckersContext` directly. This is deliberate, not a layering mistake —
  the user's own prior-experience convention: Server only ever calls into Application,
  never Persistence directly, so Application is where the actual repo-to-DbContext
  wiring happens; Persistence just hosts the DbContext/entity config/contract. Don't
  "fix" this back to Persistence again.
- `UsernamePolicy`/`PasswordPolicy` ended up in `Shared.Authentication.Policies`
  instead of Domain, specifically so the Client can reuse them for live form
  validation later (Client depends on Shared only, not Domain).

**DB strategy:** DB-first, not code-first — the user creates/maintains the actual
database schema directly rather than via EF migrations. `Microsoft.EntityFrameworkCore.Design`
was added then removed again since it's only needed for migration tooling (or
`Scaffold-DbContext` reverse-engineering, if that's ever wanted later). No
`Migrations/` folder in this repo; `UserEntityConfiguration` must be kept in sync
with the hand-maintained schema by hand.

## 11. What's actually built (as of 2026-10-14)

- `Domain/Entities/User.cs` — `PasswordHash` field.
- `Shared/Authentication/Policies/{Username,Password}Policy.cs`.
- `Shared/DTOs/{Register,Login}RequestDto.cs`, `AuthResponseDto.cs`.
- `Persistence/Data/Repositories/IRepositories/IUserRepository.cs` (contract only).
- `Application/Core/Repositories/UserRepository.cs` (implementation — see §2/§10).
- `Application/Core/Security/{IPasswordHasher,PasswordHasher,IJwtTokenService,JwtTokenService}.cs`.
- `Application/Core/Options/JwtOptions.cs`.
- `Application/Core/_interface/{IAuthService,AuthResult}.cs`, `Core/Authorization/AuthService.cs`.
- `Application/Core/Extensions/IServiceCollectionExtension.cs` — `AddCheckersAuth`.
- `Server/Controllers/AuthController.cs` — `POST /api/auth/{register,login,logout}`.
- `Server/Program.cs` — JWT bearer auth wired, fallback policy requires auth by default.
- `Server/appsettings.json` — `Jwt:{Issuer,Audience,AccessTokenExpirationMinutes}`;
  `Jwt:SigningKey` is in local user-secrets, not committed.
- DB-first, no `Migrations/` folder — `Users` table must be created by hand to match
  `UserEntityConfiguration` (see §8).
- `UnitTests` — wired with project references + Moq; 18 passing tests covering the
  policies and `AuthService`.

**Not done yet:**
- `Users` table doesn't exist in any actual database yet — nothing has run against
  a real SQL Server instance.
- No Client-side login/register UI or HTTP client calling these endpoints — Client
  still has no API/service layer per `CLAUDE.md`.
- Pre-existing, unrelated to auth: `Client` doesn't build on any platform target
  right now (`MauiProgram`/`NotFound` reference errors) — predates this session.
- Pre-existing: `Server/appsettings.json` still carries the AutoMapper license key
  and SQL Server password in plain text (flagged in §7, not fixed).
