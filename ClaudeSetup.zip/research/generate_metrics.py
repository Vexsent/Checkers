#!/usr/bin/env python3
"""
Extracts real token-usage, cost, and response-speed metrics from THIS
project's local Claude Code session transcripts (JSONL files under
~/.claude/projects/<this-project-slug>/) for the senior research paper
comparing context frameworks as Claude coding-tool candidates.

Deliberately isolated per project: each candidate framework lives in its
own project directory, and this script only ever reads the Claude Code
transcript folder that corresponds to the directory it's run from (derived
the same way Claude Code derives it — no hardcoded project name), so
copying this unmodified file into a new candidate project and running it
there produces an equally isolated, directly comparable dataset with zero
risk of one candidate's data leaking into another's.

Source of truth: the transcripts' own `message.usage` blocks (Anthropic
API usage accounting) and `timestamp` fields — no estimates.

Usage:
    python research/generate_metrics.py

Outputs (into research/):
    session_metrics.csv  — one row per Claude Code session
    turn_metrics.csv      — one row per assistant response (turn)
"""

import csv
import json
import os
from datetime import datetime, timezone
from pathlib import Path


def claude_project_slug(path: Path) -> str:
    """Reproduce Claude Code's ~/.claude/projects/<slug> naming for `path`.

    Claude Code derives the slug from the resolved absolute path by
    replacing ':' and path separators with '-' (e.g.
    C:\\Users\\x\\repo -> C--Users-x-repo). Deriving it here instead of
    hardcoding one project's slug is what makes this file copy-paste
    portable across every candidate framework's project directory.
    """
    resolved = str(path.resolve())
    return resolved.replace(":", "-").replace("\\", "-").replace("/", "-")


# Set this if a candidate project's framework isn't auto-detectable from a
# marker file/directory (see FRAMEWORK_MARKERS below) — e.g. FRAMEWORK_OVERRIDE
# = "letta" or "baseline-no-framework". Leave None to rely on auto-detection.
FRAMEWORK_OVERRIDE = None

# Marker path (relative to the project root) -> framework label. Checked in
# order; first match wins. Extend this per candidate as new frameworks are
# added to the study instead of hardcoding a single project's framework name.
FRAMEWORK_MARKERS = {
    ".mempalace": "mempalace",
    ".openclaw": "openclaw",
    ".agent-hermes": "agent-hermes",
}


def detect_framework(project_root: Path) -> str:
    if FRAMEWORK_OVERRIDE:
        return FRAMEWORK_OVERRIDE
    for marker, label in FRAMEWORK_MARKERS.items():
        if (project_root / marker).exists():
            return label
    return "unknown"


# Sessions to leave out of the comparison dataset — record the reason for
# each so the exclusion is documented and reproducible, not a silent edit.
EXCLUDED_SESSIONS = {
    # Framework setup/onboarding + building this very metrics script, not
    # representative of normal framework-assisted development work.
    "61f64657-f2ee-4efe-b180-6f5b9170a07e": "mempalace setup + metrics-tooling session, not normal dev work",
}

PROJECT_ROOT = Path(__file__).resolve().parent.parent
TRANSCRIPT_DIR = Path.home() / ".claude" / "projects" / claude_project_slug(PROJECT_ROOT)
OUTPUT_DIR = Path(__file__).parent
FRAMEWORK = detect_framework(PROJECT_ROOT)

# Anthropic API pricing, $ per million tokens (see claude-api skill, cached 2026-06-24).
# cache_write_5m = input * 1.25, cache_write_1h = input * 2, cache_read = input * 0.1
PRICING = {
    "claude-sonnet-5":   {"input": 2.00,  "output": 10.00},
    "claude-sonnet-4-6": {"input": 3.00,  "output": 15.00},
    "claude-opus-5":     {"input": 5.00,  "output": 25.00},
    "claude-opus-4-8":   {"input": 5.00,  "output": 25.00},
    "claude-opus-4-7":   {"input": 5.00,  "output": 25.00},
    "claude-opus-4-6":   {"input": 5.00,  "output": 25.00},
    "claude-haiku-4-5":  {"input": 1.00,  "output": 5.00},
    "claude-fable-5-1":  {"input": 10.00, "output": 50.00},
    "claude-fable-5":    {"input": 10.00, "output": 50.00},
}


def parse_ts(ts: str) -> datetime:
    return datetime.fromisoformat(ts.replace("Z", "+00:00"))


def cost_for_turn(model: str, input_tokens: int, output_tokens: int,
                   cache_read: int, cache_write_5m: int, cache_write_1h: int) -> float:
    rates = PRICING.get(model)
    if rates is None:
        return float("nan")
    per_tok_in = rates["input"] / 1_000_000
    per_tok_out = rates["output"] / 1_000_000
    return (
        input_tokens * per_tok_in
        + output_tokens * per_tok_out
        + cache_read * per_tok_in * 0.1
        + cache_write_5m * per_tok_in * 1.25
        + cache_write_1h * per_tok_in * 2.0
    )


def process_session(path: Path):
    with open(path, encoding="utf-8") as f:
        entries = []
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                continue

    by_uuid = {e["uuid"]: e for e in entries if e.get("uuid")}
    session_id = path.stem

    # Claude Code logs one JSONL "assistant" line per content block (text,
    # tool_use, ...) of a single real API response. All blocks of one
    # response share the same message.id and carry the SAME usage totals
    # (usage is billed per API response, not per block) — grouping by
    # message.id is required or tokens/cost get multiplied by block count.
    blocks_by_message_id = {}
    for e in entries:
        if e.get("type") != "assistant":
            continue
        message = e.get("message", {})
        usage = message.get("usage")
        if not usage:
            continue
        mid = message.get("id")
        if not mid:
            continue
        blocks_by_message_id.setdefault(mid, []).append(e)

    turns = []
    all_ts = [parse_ts(e["timestamp"]) for e in entries if e.get("timestamp")]

    for mid, blocks in blocks_by_message_id.items():
        blocks.sort(key=lambda b: b.get("apiBlockIndex", 0))
        first_block, last_block = blocks[0], blocks[-1]
        usage = first_block["message"]["usage"]
        model = first_block["message"].get("model", "unknown")

        input_tokens = usage.get("input_tokens", 0)
        output_tokens = usage.get("output_tokens", 0)
        cache_read = usage.get("cache_read_input_tokens", 0)
        cache_creation = usage.get("cache_creation", {}) or {}
        cache_write_5m = cache_creation.get("ephemeral_5m_input_tokens", 0)
        cache_write_1h = cache_creation.get("ephemeral_1h_input_tokens", 0)

        # Real trigger is the parent of the FIRST block (a user/tool-result/
        # attachment entry); later blocks chain to the previous block of the
        # same message, not to a new trigger.
        trigger = by_uuid.get(first_block.get("parentUuid"))
        latency_sec = None
        if trigger and trigger.get("timestamp") and last_block.get("timestamp"):
            latency_sec = (parse_ts(last_block["timestamp"]) - parse_ts(trigger["timestamp"])).total_seconds()

        cost = cost_for_turn(model, input_tokens, output_tokens, cache_read, cache_write_5m, cache_write_1h)
        tokens_per_sec = (output_tokens / latency_sec) if latency_sec and latency_sec > 0 else None
        cost_per_sec = (cost / latency_sec) if latency_sec and latency_sec > 0 else None

        turns.append({
            "framework": FRAMEWORK,
            "session_id": session_id,
            "message_id": mid,
            "timestamp": last_block.get("timestamp"),
            "model": model,
            "latency_sec": round(latency_sec, 3) if latency_sec is not None else "",
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "cache_read_tokens": cache_read,
            "cache_write_5m_tokens": cache_write_5m,
            "cache_write_1h_tokens": cache_write_1h,
            "cost_usd": round(cost, 6),
            "tokens_per_sec": round(tokens_per_sec, 2) if tokens_per_sec is not None else "",
            "cost_per_sec_usd": round(cost_per_sec, 8) if cost_per_sec is not None else "",
        })

    turns.sort(key=lambda t: t["timestamp"] or "")

    if not all_ts:
        return turns, None

    session_start = min(all_ts)
    session_end = max(all_ts)
    duration_min = (session_end - session_start).total_seconds() / 60.0

    total_input = sum(t["input_tokens"] for t in turns)
    total_output = sum(t["output_tokens"] for t in turns)
    total_cache_read = sum(t["cache_read_tokens"] for t in turns)
    total_cache_write = sum(t["cache_write_5m_tokens"] + t["cache_write_1h_tokens"] for t in turns)
    total_cost = sum(t["cost_usd"] for t in turns)
    latencies = [t["latency_sec"] for t in turns if t["latency_sec"] != ""]
    tps_values = [t["tokens_per_sec"] for t in turns if t["tokens_per_sec"] != ""]

    summary = {
        "framework": FRAMEWORK,
        "session_id": session_id,
        "start": session_start.isoformat(),
        "end": session_end.isoformat(),
        "duration_min": round(duration_min, 2),
        "num_turns": len(turns),
        "total_input_tokens": total_input,
        "total_output_tokens": total_output,
        "total_cache_read_tokens": total_cache_read,
        "total_cache_write_tokens": total_cache_write,
        "total_tokens": total_input + total_output + total_cache_read + total_cache_write,
        "total_cost_usd": round(total_cost, 4),
        "avg_latency_sec": round(sum(latencies) / len(latencies), 3) if latencies else "",
        "avg_tokens_per_sec": round(sum(tps_values) / len(tps_values), 2) if tps_values else "",
        # cost-vs-speed metric: $ spent per second of session wall-clock time
        "cost_per_second_usd": round(total_cost / (duration_min * 60), 8) if duration_min > 0 else "",
    }
    return turns, summary


def main():
    session_files = sorted(TRANSCRIPT_DIR.glob("*.jsonl"))
    all_turns = []
    all_summaries = []

    for path in session_files:
        if path.stem in EXCLUDED_SESSIONS:
            print(f"Excluding session {path.stem}: {EXCLUDED_SESSIONS[path.stem]}")
            continue
        turns, summary = process_session(path)
        all_turns.extend(turns)
        if summary:
            all_summaries.append(summary)

    turn_csv = OUTPUT_DIR / f"turn_metrics_{FRAMEWORK}.csv"
    with open(turn_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "framework", "session_id", "message_id", "timestamp", "model", "latency_sec",
            "input_tokens", "output_tokens", "cache_read_tokens",
            "cache_write_5m_tokens", "cache_write_1h_tokens",
            "cost_usd", "tokens_per_sec", "cost_per_sec_usd",
        ])
        writer.writeheader()
        writer.writerows(all_turns)

    session_csv = OUTPUT_DIR / f"session_metrics_{FRAMEWORK}.csv"
    with open(session_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "framework", "session_id", "start", "end", "duration_min", "num_turns",
            "total_input_tokens", "total_output_tokens",
            "total_cache_read_tokens", "total_cache_write_tokens", "total_tokens",
            "total_cost_usd", "avg_latency_sec", "avg_tokens_per_sec", "cost_per_second_usd",
        ])
        writer.writeheader()
        writer.writerows(all_summaries)

    print(f"Framework detected: {FRAMEWORK}")
    if FRAMEWORK == "unknown":
        print("  (no known marker found — set FRAMEWORK_OVERRIDE at the top of this "
              "script to label this candidate, then re-run)")
    print(f"Sessions found: {len(all_summaries)}")
    print(f"Wrote {turn_csv} ({len(all_turns)} rows)")
    print(f"Wrote {session_csv} ({len(all_summaries)} rows)")


if __name__ == "__main__":
    main()
