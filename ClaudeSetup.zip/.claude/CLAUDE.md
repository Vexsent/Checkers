# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project status

This is a brand-new, mostly-scaffolded .NET 10 solution for a checkers game (`README.md`: "A simple checkers application"). Most projects currently contain only an empty placeholder `Class1.cs` — the real domain model, game rules, and UI have not been implemented yet. `Domain/Entities/` exists but is empty. Expect to be building core functionality from scratch rather than modifying established patterns.

## Commands

Build the whole solution:
```
dotnet build Checkers.slnx
```

Run the API server (`Server`, ASP.NET Core Web API):
```
dotnet run --project Server
```

Run the client app (`Client`, .NET MAUI Blazor Hybrid):
```
dotnet build -t:Run -f net10.0-windows10.0.19041.0 Client/Client.csproj
```
(Swap the `-f` target framework for `net10.0-android`, `net10.0-ios`, or `net10.0-maccatalyst` when targeting another platform. iOS/MacCatalyst targets only build on non-Linux hosts.)

Run all tests:
```
dotnet test UnitTests/UnitTests.csproj
```
Run a single test (xUnit):
```
dotnet test UnitTests/UnitTests.csproj --filter "FullyQualifiedName~UnitTests.UnitTest1.Test1"
```

## Architecture

The solution (`Checkers.slnx`) is a layered .NET 10 solution with project references enforcing a one-directional dependency graph:

- **Shared** — base project referenced by nearly everything (DTOs/contracts meant to be common to server and client); currently empty.
- **Domain** → depends on Shared. Intended home for core game entities/rules (`Domain/Entities/`); currently empty.
- **Persistence** → depends on Domain. Intended data-access layer; currently empty.
- **Application** → depends on Persistence and Shared. Intended application/use-case layer sitting between Domain/Persistence and the Server; currently empty.
- **Server** (`Microsoft.NET.Sdk.Web`) → depends on Application and Shared. ASP.NET Core Web API; `Program.cs` is a minimal-hosting-model API with controllers and OpenAPI enabled, currently only exposing the template `WeatherForecastController`.
- **Client** (`Microsoft.NET.Sdk.Razor`, `UseMaui=true`, `SingleProject=true`) → depends on Shared only (not on Application/Domain/Persistence/Server). A .NET MAUI Blazor Hybrid app targeting Android, Windows, and (on non-Linux hosts) iOS/MacCatalyst, using Radzen.Blazor for UI components. Blazor pages/layout live under `Client/Components/`.
- **UnitTests** (xUnit) — sits oddly in the dependency graph: `Application` and `Shared` both declare a *build dependency* on `UnitTests`, meaning UnitTests currently has no project references of its own and isn't yet wired to test the other layers directly.

When implementing game logic, the intended flow is: **Domain** holds entities/rules → **Persistence** persists them → **Application** orchestrates use cases → **Server** exposes them via API → **Client** consumes them (currently only via Shared contracts, not via HTTP calls yet — there's no client-side API/service layer present).

Target framework across all projects is `net10.0` (or a `net10.0-<platform>` TFM for Client).
